const $ = require("jquery")
const electron = require("electron")
const fs = require('fs');
const cheerio = require('cheerio');
const open = require('open');
const ipc = electron.ipcRenderer
const EventEmitter = require("events");
const j = require('request').jar();
const request = require('request').defaults({
    timeout: 60000,
    jar: j,
});
const host = 'http://localhost:3000'

//Minimize App
$("#minimize-action").click(function(){
    ipc.send("minimize-app");
});
//Closing App
$("#close-action").click(function(){
    ipc.send("close-app");
})
//Log-our App
$("#logout-action").click(function(){
    ipc.send("logout");
})

$(".nav-link").click(function(){
    //Getting Current Window and target window
    let currentWindow = $(".active-anchor").attr("alt")
    let targetId = $(this).attr("alt")
    //Opening and closing target and current window respectively
    $(".active-anchor").removeClass("active-anchor");
    $(".active").removeClass("active");
    $(this).addClass("active-anchor");
    $("#"+targetId+"-id").addClass("active");
    $(".section_identity").addClass("hide_section");
    $(".section_identity").removeClass("show_section");
    $(".section_identity").removeClass("animated fadeInLeft");
    $("#current-page").html(targetId.charAt(0).toUpperCase() + targetId.slice(1))

    if(targetId == "task"){
        $("#body-change").removeClass("page-height");
        $("#body-change").removeClass("no_scroll");
        $("#body-change").addClass("no_scroll");
        $("#"+targetId).removeClass("hide_section")
        $("#"+targetId).addClass("animated fadeInLeft")
    }else {
        $("#body-change").removeClass("page-height");
        $("#body-change").removeClass("no_scroll");
        $("#body-change").addClass("page-height");
        $("#"+targetId).removeClass("hide_section")

        $("#"+targetId).addClass("animated fadeInLeft")
    }


})

//On Document Ready Showing Saved Profiles
$(document).ready(function(){
    request({
        url : host+'/getRegions',
        method: 'get',
       
    }, function(ee, res, body) {
        var regions = JSON.parse(body);
        console.log(regions.data[0]);
        var html= '<option value="">Select Region</option>';
        regions.data.forEach(function(item){
            html = '<option value="'+item.id+'">'+item.name+'<option>';
            $("#launch-regions").append(html);
            $("#source-launch-regions").append(html);
            $("#destination-launch-regions").append(html);
        })
        
    })

    $("#start-launch").click(function(){
        var region = $("#launch-regions").val();
        if (region == '') {
            displayAlert('Please select a region')
        } else {
            var params = {
                url : host+'/initiate/'+region,
                method: 'get'
            }
            request(params, function(ee, res, body){
                if (!ee) {
                    var response  = JSON.parse(body);
                    if (response.status == 'success') {
                        displayAlert('Launch Successfull')
                    } else {
                        displayAlert('Unable to Launch')
                        
                    }
                    console.log(response);
                } else {
                    console.log(ee)
                }
            });
        }
    });

    $("#migration-start").click(function() {
        var destinationRegion = $("#destination-launch-regions").val();
        var sourceRegion = $("#source-launch-regions").val();
        if (destinationRegion == '' || sourceRegion == '') {
            displayAlert('Please select source and destination regions');

        } else {
            var cpParams =  {
                url : host+'/moveImage/'+sourceRegion+'/'+destinationRegion,
                 method: 'get'
            }
            request(cpParams, function(ee, res, body){
                if (!ee) {
                    displayAlert('Entered Outer Space')
                    var response  = JSON.parse(body);
                    if(response.status == 'success'){
                        var miParams = {
                            url : host+'/migrate/'+sourceRegion+'/'+destinationRegion,
                            method: 'get'
                        }
                        
                        request(miParams, function(err, res, body){
                            var response  = JSON.parse(body);         
                            if(response.status == 'success') {
                                displayAlert('Rocket Placed In Orbit')
                            } else {
                                displayAlert('Rocket Crashed')
                            }
                        })
                    }
                }else {

                }
            });
        }
    });

    function displayAlert(alertMessage){
        $("#errorMessage").html(alertMessage)
        $("#pop-form-task-err").addClass("show_deleted");
        setTimeout(function(){ $("#pop-form-task-err").removeClass("show_deleted"); }, 2000);

    }

})

